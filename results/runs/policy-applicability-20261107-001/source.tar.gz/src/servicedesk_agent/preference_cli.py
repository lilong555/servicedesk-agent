"""Human approval boundary for preferences extracted from checkpointed conversations."""

from __future__ import annotations

import json
import re
from pathlib import Path
from uuid import uuid4

from langchain_core.messages import HumanMessage
from langgraph.store.sqlite import SqliteStore

from servicedesk_agent.config import ModelSettings
from servicedesk_agent.domain import BusinessError, fingerprint
from servicedesk_agent.preferences import PreferenceMemory, PreferencePreview
from servicedesk_agent.session import load_session
from servicedesk_agent.usage import UsageRecorder


def preference_command(root: Path, client, identity, args) -> dict:
    client._check_contract(identity)
    client.get_ticket(identity.ticket_id)
    with SqliteStore.from_conn_string(str(root / "memory.sqlite")) as store:
        store.setup()
        memory = PreferenceMemory(identity.scope, store)
        if args.preference_command == "list":
            if not 1 <= args.limit <= 100:
                raise ValueError("Use a preference page size from 1 to 100.")
            records = memory.recall(limit=args.limit, offset=args.offset)
            return {"preferences": [item.model_dump(mode="json") for item in records]}
        state = load_session(root, client, identity)
        if not state:
            raise BusinessError("session_missing", "Start a session before extracting preferences.")
        messages = state.get("messages", [])
        human = [message for message in messages if isinstance(message, HumanMessage)]
        if args.preference_command == "messages":
            return {
                "messages": [{"id": message.id, "text": message.content} for message in human[-20:]]
            }
        directory = root / "preferences" / fingerprint(identity.scope) / "previews"
        if args.preference_command == "confirm":
            if not re.fullmatch(r"[0-9a-f]{32}", args.preview):
                raise ValueError("Provide a returned preference preview ID.")
            path = directory / f"{args.preview}.json"
            if not path.is_file() or path.is_symlink() or path.stat().st_size > 1_000_000:
                raise BusinessError("preview_unavailable", "The preference preview is unavailable.")
            record = json.loads(path.read_text(encoding="utf-8"))
            if record["thread_id"] != identity.thread_id:
                raise BusinessError("scope_mismatch", "Confirm the preview in its source session.")
            preview = PreferencePreview.model_validate(record["preview"])
            for source in preview.sources:
                matching = [message for message in human if message.id == source.message_id]
                if len(matching) != 1 or matching[0].content != source.text:
                    raise BusinessError(
                        "preference_source_changed",
                        "Extract a new preview from the current session.",
                    )
            results = memory.commit(preview, confirmed=True)
            return {"preview_id": args.preview, "confirmed": True, "results": results}
        ids = args.message_id or ([human[-1].id] if human else [])
        if not ids or len(ids) > 20 or any(not value for value in ids):
            raise ValueError("Select from 1 to 20 saved human message IDs.")
        settings = ModelSettings.from_env()
        model = settings.build()
        usage = UsageRecorder()
        try:
            preview = memory.preview(
                messages, confirmed_message_ids=ids, model=model, config={"callbacks": [usage]}
            )
        finally:
            model.root_client.close()
        preview_id = uuid4().hex
        record = {
            "thread_id": identity.thread_id,
            "preview": preview.model_dump(mode="json"),
            "usage": usage.summary(settings),
        }
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        path = directory / f"{preview_id}.json"
        with path.open("x", encoding="utf-8") as output:
            path.chmod(0o600)
            json.dump(record, output, ensure_ascii=True, indent=2)
        return {
            "preview_id": preview_id,
            "confirmed": False,
            "candidates": [item.model_dump(mode="json") for item in preview.candidates],
            "usage": record["usage"],
        }
