"""Process-safe ownership around the native SQLite checkpointer."""

from __future__ import annotations

import fcntl
import json
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from typing import Any
from uuid import uuid4

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage, messages_to_dict
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START

from servicedesk_agent.agent import build_desk_agent
from servicedesk_agent.components import ComponentBundle
from servicedesk_agent.control import HandoffMiddleware, SessionControl
from servicedesk_agent.domain import BusinessError, TaskContract
from servicedesk_agent.testing import ScriptedChatModel
from servicedesk_agent.usage import UsageRecorder


class _AtomicSqliteSaver(SqliteSaver):
    @contextmanager
    def cursor(self, transaction: bool = True):
        # The owning session commits all native checkpoint updates together.
        with super().cursor(transaction=False) as cursor:
            yield cursor


@contextmanager
def session_storage(root: Path, thread_id: str, *, atomic: bool = False):
    directory = root / "sessions" / thread_id
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (directory / "session.lock").open("a") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise BusinessError("session_busy", "Another process owns this session.") from exc
        try:
            saver_type = _AtomicSqliteSaver if atomic else SqliteSaver
            with saver_type.from_conn_string(str(directory / "checkpoint.sqlite")) as saver:
                if atomic:
                    saver.setup()
                    with saver.conn:
                        yield saver, directory
                else:
                    yield saver, directory
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def load_session(root: Path, client, identity: TaskContract) -> dict[str, Any]:
    with session_storage(root, identity.thread_id) as (saver, _):
        graph = _restored_graph(saver, root, client, identity)
        state = dict(graph.get_state({"configurable": {"thread_id": identity.thread_id}}).values)
        if state:
            stored = TaskContract.model_validate(state["contract"])
            if stored.thread_id != identity.thread_id:
                raise BusinessError("contract_changed", "The saved contract has a different scope.")
        return state


def _superseded_tool_results(
    messages,
    *,
    error: str = "superseded_by_user_input",
    message: str | None = None,
) -> list[ToolMessage]:
    answered = {item.tool_call_id for item in messages if isinstance(item, ToolMessage)}
    results = []
    for item in messages:
        if not isinstance(item, AIMessage):
            continue
        for call in (*item.tool_calls, *item.invalid_tool_calls):
            if call["id"] is None or call["id"] in answered:
                continue
            results.append(
                ToolMessage(
                    content=json.dumps(
                        {
                            "ok": False,
                            "error": error,
                            "retry_cancelled": True,
                            "execution_outcome": "unknown",
                            "message": message
                            or (
                                "A new user message superseded this pending tool call. "
                                "Its execution or retry has been cancelled. No result was "
                                "recorded; earlier execution may have produced side effects. "
                                "Reconcile possible writes through read-only evidence and "
                                "verified receipts; keep unconfirmed outcomes unresolved. "
                                "Plan subsequent actions using the latest user message."
                            ),
                        }
                    ),
                    tool_call_id=call["id"],
                    name=call["name"] or "unknown",
                    status="error",
                )
            )
            answered.add(call["id"])
    return results


def _handoff_results(messages):
    return _superseded_tool_results(
        messages,
        error="session_writes_revoked",
        message=(
            "Human takeover cancelled this pending invocation or retry. Earlier execution "
            "may have produced side effects. Reconcile through read-only evidence and "
            "verified receipts; keep unconfirmed outcomes unresolved."
        ),
    )


def _controlled_components(components, control, epoch):
    bundle = components if components is not None else ComponentBundle()
    return replace(
        bundle,
        agent_kwargs={
            **bundle.agent_kwargs,
            "middleware": [
                *bundle.agent_kwargs.get("middleware", []),
                HandoffMiddleware(control, epoch, _handoff_results),
            ],
        },
    )


def _restored_graph(saver, root, client, identity):
    components = ComponentBundle(agent_kwargs={"skills": []}) if identity.variant == "B" else None
    control = SessionControl(root, identity)
    if control.path.is_file():
        components = _controlled_components(components, control, control.read()["epoch"])
    return build_desk_agent(
        ScriptedChatModel(), client, identity, checkpointer=saver, components=components
    )


def _clear_tasks(graph, config):
    while graph.get_state(config).tasks:
        graph.update_state(config, None, as_node=END)


def _apply_takeover(graph, config, request):
    existing = graph.get_state(config)
    stored = TaskContract.model_validate(existing.values["contract"])
    readonly = stored.model_copy(
        update={"allow_notes": False, "allowed_status_ids": (), "allow_close": False}
    )
    messages = _handoff_results(existing.values.get("messages", []))
    if existing.tasks:
        graph.update_state(config, None, as_node=END)
    graph.update_state(
        config,
        {
            "contract": readonly.model_dump(mode="json"),
            "messages": [
                *messages,
                HumanMessage(content=request["message"], id=f"takeover-{request['epoch']}"),
            ],
        },
        as_node=START,
    )
    _clear_tasks(graph, config)
    return dict(graph.get_state(config).values)


def _control_result(state, control):
    return {
        "thread_id": control["thread_id"],
        "control_status": control["status"],
        "control_epoch": control["epoch"],
        "contract": state["contract"],
        "pending_actions": state.get("pending_actions", []),
        "handoff_summary": state.get("handoff_summary", ""),
        "verified_receipts": list(state.get("receipts", {}).values()),
    }


def _ticket_messages(ticket, call_id):
    return [
        AIMessage(content="", tool_calls=[{"name": "read_ticket", "args": {}, "id": call_id}]),
        ToolMessage(
            content=json.dumps({"ok": True, "ticket": ticket.model_dump(mode="json")}),
            tool_call_id=call_id,
            name="read_ticket",
        ),
    ]


def _current_reply(state, user_message_id):
    messages = state.get("messages", [])
    start = next((i for i, message in enumerate(messages) if message.id == user_message_id), None)
    if start is None:
        return ""
    last = next(
        (item for item in reversed(messages[start + 1 :]) if isinstance(item, AIMessage)), None
    )
    if last is None or last.tool_calls or last.invalid_tool_calls:
        return ""
    return last.text


def takeover_session(
    root: Path, client, identity: TaskContract, message: str = "Human takeover requested."
) -> dict[str, Any]:
    """Persist a takeover during an active run; acknowledge human ownership when drained.

    The returned takeover_requested status allows already-admitted HTTP to settle.
    Call handback_session with explicit grants before starting another agent run.
    """
    if not message.strip():
        raise ValueError("Provide a nonempty takeover message.")
    client._check_contract(identity)
    control = SessionControl(root, identity)
    checkpoint = control.directory / "checkpoint.sqlite"
    if not checkpoint.is_file():
        raise BusinessError("session_missing", "Start this session before taking over.")
    # This independent connection only reads native state; it never takes session.lock.
    with SqliteSaver.from_conn_string(str(checkpoint)) as saver:
        graph = _restored_graph(saver, root, client, identity)
        state = dict(graph.get_state({"configurable": {"thread_id": identity.thread_id}}).values)
    if not state:
        raise BusinessError("session_missing", "Start this session before taking over.")
    stored = TaskContract.model_validate(state["contract"])
    if stored.thread_id != identity.thread_id:
        raise BusinessError("contract_changed", "The saved contract has a different scope.")
    if not control.path.is_file():
        control.initialize()
    request = control.request(message.strip())
    client.set_session_write_guard(identity.thread_id, control.write_guard(request["epoch"]))
    try:
        with session_storage(root, identity.thread_id, atomic=True) as (saver, _):
            graph = _restored_graph(saver, root, client, stored)
            state = _apply_takeover(
                graph, {"configurable": {"thread_id": identity.thread_id}}, request
            )
            saver.conn.commit()
            request = control.acknowledge(request["epoch"])
    except BusinessError as exc:
        if exc.code not in {"session_busy", "control_changed"}:
            raise
        request = control.read()
    return _control_result(state, request)


request_takeover = takeover_session


def handback_session(
    root: Path,
    client,
    identity: TaskContract,
    message: str,
    *,
    grants: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Refresh evidence and return control with explicitly supplied write grants.

    grants accepts allow_notes, allowed_status_ids and allow_close; omitted grants
    return read-only agent control. Resume using the returned contract and message.
    Failed refresh/checkpoint operations retain the durable takeover fence.
    """
    if not message.strip():
        raise ValueError("Provide a nonempty handback instruction.")
    grants = {} if grants is None else dict(grants)
    if grants.keys() - {"allow_notes", "allowed_status_ids", "allow_close"}:
        raise ValueError("Provide only explicit note, status and closure grants.")
    with session_storage(root, identity.thread_id, atomic=True) as (saver, _):
        client._check_contract(identity)
        graph = _restored_graph(saver, root, client, identity)
        config = {"configurable": {"thread_id": identity.thread_id}}
        existing = graph.get_state(config)
        if not existing.values:
            raise BusinessError("session_missing", "Start this session before returning control.")
        stored = TaskContract.model_validate(existing.values["contract"])
        if stored.thread_id != identity.thread_id:
            raise BusinessError("contract_changed", "The saved contract has a different scope.")
        graph = _restored_graph(saver, root, client, stored)
        control = SessionControl(root, stored)
        if not control.path.is_file():
            raise BusinessError(
                "takeover_required", "Request human takeover before returning control."
            )
        request = control.read()
        if request["status"] == "agent":
            raise BusinessError(
                "takeover_required", "Request human takeover before returning control."
            )
        contract = TaskContract.model_validate(
            {
                **stored.model_dump(mode="json"),
                "allow_notes": False,
                "allowed_status_ids": [],
                "allow_close": False,
                **grants,
            }
        )
        # Read-back settles sent requests independently of the new write grants.
        reconciliation_error = None
        receipts = []
        try:
            receipts = client.reconcile_operations(contract, include_completed=True)
        except BusinessError as exc:
            if exc.code != "operation_uncertain":
                raise
            reconciliation_error = exc.as_dict()
        ticket = client.get_ticket(contract.ticket_id)
        _apply_takeover(graph, config, request)
        graph.update_state(
            config,
            {
                "contract": contract.model_dump(mode="json"),
                "messages": [
                    *_ticket_messages(ticket, f"handback-read-{uuid4().hex}"),
                    HumanMessage(content=message.strip()),
                ],
                "observations": {ticket.evidence.source_version: ticket.model_dump(mode="json")},
                "receipts": {
                    receipt.operation_id: receipt.model_dump(mode="json") for receipt in receipts
                },
            },
            as_node=START,
        )
        _clear_tasks(graph, config)
        saver.conn.commit()
        authorized = control.authorize(request["epoch"])
        client.set_session_write_guard(
            identity.thread_id, control.write_guard(authorized["epoch"], contract)
        )
        result = _control_result(dict(graph.get_state(config).values), authorized)
        return {
            **result,
            "message": message.strip(),
            "ticket": ticket.model_dump(mode="json"),
            "reconciliation_error": reconciliation_error,
        }


def revoke_session_writes(root: Path, client, identity: TaskContract) -> dict[str, Any]:
    with session_storage(root, identity.thread_id, atomic=True) as (saver, _):
        client._check_contract(identity)
        config = {"configurable": {"thread_id": identity.thread_id}}
        graph = _restored_graph(saver, root, client, identity)
        existing = graph.get_state(config)
        if not existing.values:
            raise BusinessError("session_missing", "Start this session before revoking writes.")
        stored = TaskContract.model_validate(existing.values["contract"])
        if stored.thread_id != identity.thread_id:
            raise BusinessError("contract_changed", "The saved contract has a different scope.")
        client._check_contract(stored)
        if stored.variant == "B":
            # Native Skills restores B's nodes and private channels without loading its
            # policy catalog, memory tools, skill sources, or external configuration.
            graph = _restored_graph(saver, root, client, stored)
            existing = graph.get_state(config)
        readonly = stored.model_copy(
            update={"allow_notes": False, "allowed_status_ids": (), "allow_close": False}
        )
        messages = _superseded_tool_results(
            existing.values.get("messages", []),
            error="session_writes_revoked",
            message=(
                "Session write permissions have been revoked. This pending tool call's "
                "execution or retry has been cancelled. No result was recorded; earlier "
                "execution may have produced side effects. Reconcile possible writes "
                "through read-only evidence and verified receipts; keep unconfirmed "
                "outcomes unresolved. Plan subsequent actions using the read-only contract."
            ),
        )
        if existing.tasks:
            # Fold completed sibling outputs into the checkpoint before changing authority.
            graph.update_state(config, None, as_node=END)
        if stored != readonly or messages:
            graph.update_state(
                config,
                {"contract": readonly.model_dump(mode="json"), "messages": messages},
                as_node=START,
            )
        stopped = graph.get_state(config)
        # Completed outputs folded by END can schedule a following model/middleware node.
        while stopped.tasks:
            graph.update_state(config, None, as_node=END)
            stopped = graph.get_state(config)
        state = dict(stopped.values)
        return {
            "thread_id": readonly.thread_id,
            "contract": state["contract"],
            "pending_actions": state.get("pending_actions", []),
            "handoff_summary": state.get("handoff_summary", ""),
            "verified_receipts": list(state.get("receipts", {}).values()),
        }


def execute_session(
    root: Path,
    client,
    contract: TaskContract,
    model,
    message: str,
    *,
    resume: bool = False,
    components=None,
    model_settings=None,
    recursion_limit: int = 60,
    max_concurrency: int | None = None,
) -> dict[str, Any]:
    if not message.strip():
        raise ValueError("Provide a nonempty task message.")
    usage = UsageRecorder()
    with session_storage(root, contract.thread_id) as (saver, directory):
        control = SessionControl(root, contract)
        authority = control.initialize()
        config = {
            "configurable": {"thread_id": contract.thread_id},
            "recursion_limit": recursion_limit,
            "callbacks": [usage],
        }
        if max_concurrency is not None:
            config["max_concurrency"] = max_concurrency
        graph = _restored_graph(saver, root, client, contract)
        existing = graph.get_state(config)
        if existing.values and not resume:
            raise BusinessError("session_exists", "Use resume to continue this existing session.")
        if not existing.values and resume:
            raise BusinessError("session_missing", "Start this session before resuming it.")
        if existing.values:
            stored = TaskContract.model_validate(existing.values["contract"])
            if stored.thread_id != contract.thread_id:
                raise BusinessError("contract_changed", "The saved contract has a different scope.")
        client._check_contract(contract)
        if existing.values and authority["status"] != "agent":
            _apply_takeover(_restored_graph(saver, root, client, stored), config, authority)
            control.acknowledge(authority["epoch"])
            raise BusinessError("session_taken_over", "Return control explicitly before resuming.")
        if existing.values:
            if stored != contract:
                raise BusinessError("contract_changed", "Resume with the persisted task contract.")
        catalog = getattr(components, "policy_catalog", None)
        prior_binding = existing.values.get("policy_binding") or None
        if prior_binding is not None and catalog is None:
            raise BusinessError(
                "policy_configuration_required", "Resume with the persisted policy configuration."
            )
        policy_binding = catalog.binding(prior_binding) if catalog is not None else None
        if not existing.values:
            initial_state = components.initial_state if components is not None else {}
            if initial_state.keys() & {
                "contract",
                "receipts",
                "observations",
                "pending_actions",
                "handoff_summary",
                "messages",
                "policy_reviews",
                "policy_binding",
                "workflow",
            }:
                raise BusinessError(
                    "invalid_component_state", "Component state includes reserved session records."
                )
        graph = build_desk_agent(
            model,
            client,
            contract,
            checkpointer=saver,
            components=_controlled_components(components, control, authority["epoch"]),
        )
        existing = graph.get_state(config)
        client.set_session_write_guard(
            contract.thread_id, control.write_guard(authority["epoch"], contract)
        )
        if not existing.values:
            graph.update_state(
                config,
                {
                    **initial_state,
                    "contract": contract.model_dump(mode="json"),
                    "pending_actions": [],
                    "handoff_summary": "",
                    "receipts": {},
                    "observations": {},
                    **({"policy_binding": policy_binding} if policy_binding is not None else {}),
                },
            )
        run_id = uuid4().hex
        user_message = HumanMessage(content=message, id=f"user-{run_id}")
        failure = None
        reply = ""
        try:
            if existing.tasks:
                # END folds in completed sibling outputs and clears queued tasks without
                # executing them. The live snapshot already includes those saved outputs.
                graph.update_state(config, None, as_node=END)
            messages = _superseded_tool_results(existing.values.get("messages", []))
            if existing.values and policy_binding != prior_binding:
                graph.update_state(config, {"policy_binding": policy_binding})
            if resume:
                ticket = client.get_ticket(contract.ticket_id)
                if ticket.evidence.source_version not in existing.values.get("observations", {}):
                    messages.extend(_ticket_messages(ticket, f"resume-read-{run_id}"))
                    graph.update_state(
                        config,
                        {
                            "observations": {
                                ticket.evidence.source_version: ticket.model_dump(mode="json")
                            }
                        },
                    )
            graph.invoke({"messages": [*messages, user_message]}, config)
        except BaseException as exc:
            failure = exc
            raise
        finally:
            try:
                authority = control.read()
                if authority["status"] != "agent":
                    _apply_takeover(graph, config, authority)
                    try:
                        authority = control.acknowledge(authority["epoch"])
                    except BusinessError as exc:
                        if exc.code not in {"session_busy", "control_changed"}:
                            raise
                state = dict(graph.get_state(config).values)
                if failure is None and authority["status"] == "agent":
                    try:
                        reply = _current_reply(state, user_message.id)
                        catalog = getattr(components, "policy_catalog", None)
                        if reply and catalog is not None:
                            from servicedesk_agent.compliance import PolicyGuard

                            checked = PolicyGuard(catalog, contract).check_reply(reply)
                            if not checked["ok"]:
                                raise BusinessError(
                                    "reply_policy_violation", json.dumps(checked, ensure_ascii=True)
                                )
                    except Exception as exc:
                        failure = exc
                if catalog is not None:
                    binding = catalog.observed_binding(state.get("policy_binding"))
                    if binding != state.get("policy_binding"):
                        # Fold saved sibling outputs before recording policy discoveries
                        # at the completed or interrupted native execution boundary.
                        _clear_tasks(graph, config)
                        graph.update_state(config, {"policy_binding": binding}, as_node=START)
                        _clear_tasks(graph, config)
                        state = dict(graph.get_state(config).values)
                trace = {
                    "run_id": run_id,
                    "model_mode": "scripted" if isinstance(model, ScriptedChatModel) else "live",
                    "thread_id": contract.thread_id,
                    "error_type": type(failure).__name__ if failure is not None else None,
                    "error_code": getattr(failure, "code", None),
                    "control_status": authority["status"],
                    "usage": usage.summary(model_settings),
                    "model_calls": usage.calls,
                    "messages": messages_to_dict(state.get("messages", [])),
                    "receipt_ids": list(state.get("receipts", {})),
                }
                path = directory / f"trace-{run_id}.json"
                path.write_text(json.dumps(trace, ensure_ascii=False, indent=2), encoding="utf-8")
                path.chmod(0o600)
            except Exception as exc:
                if failure is None:
                    raise
                failure.add_note(f"Session trace finalization failed ({type(exc).__name__}).")
        if failure is not None:
            raise failure
        authority = control.read()
        if authority["status"] != "agent":
            reply = ""
        return {
            "thread_id": contract.thread_id,
            "control_status": authority["status"],
            "control_epoch": authority["epoch"],
            "message": reply,
            "contract": state["contract"],
            "pending_actions": state.get("pending_actions", []),
            "handoff_summary": state.get("handoff_summary", ""),
            "verified_receipts": list(state.get("receipts", {}).values()),
            "usage": usage.summary(model_settings),
            "trace_path": str(path),
        }
