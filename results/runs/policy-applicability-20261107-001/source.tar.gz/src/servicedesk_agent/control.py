"""Durable handoff signals and native agent admission boundaries."""

from __future__ import annotations

import fcntl
import json
import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from langchain.agents.middleware import AgentMiddleware, hook_config
from langchain_core.messages import AIMessage, ToolMessage

from servicedesk_agent.domain import BusinessError, TaskContract


class SessionControl:
    """A short-lived control transaction, independent of the run's checkpoint lock.

    A request fences subsequent admissions immediately. An admission already holding
    dispatch.lock may finish its HTTP request and read-back. Human ownership is
    acknowledged only after that admission and the active graph have drained.
    """

    def __init__(self, root: Path, identity: TaskContract):
        self.directory = root / "sessions" / identity.thread_id
        self.path = self.directory / "control.sqlite"
        self.identity = identity

    @contextmanager
    def _connection(self):
        connection = sqlite3.connect(self.path, timeout=10)
        try:
            yield connection
        finally:
            connection.close()

    def initialize(self) -> dict:
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        with self._connection() as connection:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS control (id INTEGER PRIMARY KEY, data TEXT)"
            )
            connection.execute(
                "INSERT OR IGNORE INTO control VALUES (1, ?)",
                (
                    json.dumps(
                        {
                            "thread_id": self.identity.thread_id,
                            "epoch": 0,
                            "status": "agent",
                        }
                    ),
                ),
            )
            connection.commit()
        return self.read()

    def read(self) -> dict:
        with self._connection() as connection:
            row = connection.execute("SELECT data FROM control WHERE id = 1").fetchone()
        if row is None:
            raise BusinessError("control_missing", "Restore the session control record.")
        value = json.loads(row[0])
        if value["thread_id"] != self.identity.thread_id:
            raise BusinessError("contract_changed", "The saved control has a different scope.")
        return value

    def _update(
        self, status: str, *, expected_epoch: int | None = None, message: str | None = None
    ) -> dict:
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            value = json.loads(
                connection.execute("SELECT data FROM control WHERE id = 1").fetchone()[0]
            )
            if expected_epoch is not None and value["epoch"] != expected_epoch:
                raise BusinessError("control_changed", "A newer takeover request takes priority.")
            value["status"] = status
            if message is not None:
                value["message"] = message
            if status != "human":
                value["epoch"] += 1
            connection.execute("UPDATE control SET data = ? WHERE id = 1", (json.dumps(value),))
            connection.commit()
        return value

    def request(self, message: str) -> dict:
        return self._update("takeover_requested", message=message)

    @contextmanager
    def dispatch(self, *, blocking: bool = True):
        fd = os.open(self.directory / "dispatch.lock", os.O_CREAT | os.O_RDWR, 0o600)
        with os.fdopen(fd, "a") as lock:
            flags = fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB)
            try:
                fcntl.flock(lock.fileno(), flags)
            except BlockingIOError as exc:
                raise BusinessError(
                    "session_busy", "An admitted write is still in progress."
                ) from exc
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def active(self, epoch: int) -> bool:
        value = self.read()
        return value["status"] == "agent" and value["epoch"] == epoch

    def write_guard(self, epoch: int, authorized_contract: TaskContract | None = None):
        @contextmanager
        def admission(contract: TaskContract):
            with self.dispatch():
                if contract.thread_id != self.identity.thread_id or not self.active(epoch):
                    raise BusinessError(
                        "session_writes_revoked",
                        "Human takeover revoked this run's write authority.",
                    )
                if authorized_contract is not None and contract != authorized_contract:
                    raise BusinessError(
                        "write_not_authorized", "Use the current session's explicit write grant."
                    )
                yield

        return admission

    def acknowledge(self, epoch: int) -> dict:
        with self.dispatch(blocking=False):
            return self._update("human", expected_epoch=epoch)

    def authorize(self, epoch: int) -> dict:
        # The caller owns session.lock and has committed the refreshed checkpoint.
        with self.dispatch(blocking=False):
            return self._update("agent", expected_epoch=epoch)


class HandoffMiddleware(AgentMiddleware):
    """Stop at native model/tool boundaries without replacing the agent loop."""

    def __init__(self, control: SessionControl, epoch: int, cancel_results):
        self.control = control
        self.epoch = epoch
        self.cancel_results = cancel_results

    @hook_config(can_jump_to=["end"])
    def before_model(self, state, runtime):
        if not self.control.active(self.epoch):
            return {"jump_to": "end", "messages": self.cancel_results(state.get("messages", []))}
        return None

    @hook_config(can_jump_to=["end"])
    def after_model(self, state, runtime):
        return self.before_model(state, runtime)

    def wrap_model_call(self, request, handler):
        if not self.control.active(self.epoch):
            return AIMessage(content="")
        return handler(request)

    def wrap_tool_call(self, request, handler):
        if not self.control.active(self.epoch):
            return ToolMessage(
                content=json.dumps(
                    {
                        "ok": False,
                        "error": "session_writes_revoked",
                        "retry_cancelled": True,
                        "execution_outcome": "unknown",
                        "message": "Human takeover cancelled this invocation or retry. "
                        "Reconcile any earlier execution through read-only evidence.",
                    }
                ),
                tool_call_id=request.tool_call["id"],
                name=request.tool_call["name"],
                status="error",
            )
        return handler(request)
