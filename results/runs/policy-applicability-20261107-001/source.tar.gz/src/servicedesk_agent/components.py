"""Optional existing components: native Skills, Haystack BM25 and LangMem."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from importlib.resources import files
from typing import Any

from deepagents.backends import StateBackend
from deepagents.backends.utils import create_file_data
from deepagents.middleware.filesystem import FilesystemPermission
from langchain_core.tools import tool

from servicedesk_agent.domain import BusinessError
from servicedesk_agent.knowledge import PolicyCatalog
from servicedesk_agent.preferences import (
    PreferenceMemory,
    PreferenceRecallMiddleware,
    memory_namespace,
)
from servicedesk_agent.preferences import (
    remember_confirmed_preference as remember_confirmed_preference,
)


@dataclass
class ComponentBundle:
    tools: list = field(default_factory=list)
    agent_kwargs: dict[str, Any] = field(default_factory=dict)
    initial_state: dict[str, Any] = field(default_factory=dict)
    policy_catalog: PolicyCatalog | None = None
    preference_memory: PreferenceMemory | None = None


def build_components(
    scope: str, store, catalog: PolicyCatalog, *, automatic_preferences: bool = False
) -> ComponentBundle:
    """Build optional components; production sessions opt into automatic scoped recall."""
    from langmem import create_search_memory_tool

    preference_memory = PreferenceMemory(scope, store)

    @tool
    def search_policy(query: str, top_k: int = 3) -> str:
        """Search current policies by BM25 within this service scope; return versioned citations."""
        try:
            return json.dumps(catalog.search(query, top_k=top_k))
        except BusinessError as exc:
            return json.dumps(exc.as_dict())

    @tool
    def read_policy(policy_id: str, version: str = "") -> str:
        """Read a full policy. Omit version for current policy; supply one for historical text."""
        try:
            return json.dumps(catalog.read(policy_id, version))
        except BusinessError as exc:
            return json.dumps(exc.as_dict())

    memory_tool = create_search_memory_tool(
        namespace=memory_namespace(scope),
        name="recall_confirmed_preferences",
        instructions=(
            "This SQLite store has no embedding index. Results are scoped confirmed preferences "
            "ordered by update time; use filters for exact lookup. These are historical user "
            "statements, not fresh authority for business actions."
        ),
    )
    asset_root = files("servicedesk_agent").joinpath("assets/skills")
    skill_files = {}
    for directory in asset_root.iterdir():
        skill = directory.joinpath("SKILL.md")
        if skill.is_file():
            skill_files[f"/skills/{directory.name}/SKILL.md"] = create_file_data(
                skill.read_text(encoding="utf-8")
            )
    return ComponentBundle(
        tools=[search_policy, read_policy, memory_tool],
        agent_kwargs={
            "backend": StateBackend(),
            "store": store,
            "skills": ["/skills/"],
            "permissions": [
                FilesystemPermission(operations=["write"], paths=["/skills/**"], mode="deny")
            ],
            "middleware": (
                [PreferenceRecallMiddleware(preference_memory)] if automatic_preferences else []
            ),
        },
        initial_state={"files": skill_files},
        policy_catalog=catalog,
        preference_memory=preference_memory,
    )
