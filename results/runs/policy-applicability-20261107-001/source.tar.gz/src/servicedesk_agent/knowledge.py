"""Versioned policy documents retrieved with Haystack's native BM25 component."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Literal

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, field_validator, model_validator

from servicedesk_agent.domain import BusinessError, Evidence, fingerprint, utc_now


class PolicyRules(BaseModel):
    """Service-owned controls evaluated before business writes and final replies."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    allowed_actions: tuple[Literal["add_note", "set_status", "reply"], ...] = (
        "add_note",
        "set_status",
        "reply",
    )
    allowed_status_ids: tuple[int, ...] | None = None
    required_note_phrases: tuple[str, ...] = ()
    forbidden_note_phrases: tuple[str, ...] = ()
    required_reply_phrases: tuple[str, ...] = ()
    forbidden_reply_phrases: tuple[str, ...] = ()
    require_review: bool = True
    require_reply_citations: bool = False

    @field_validator("allowed_status_ids")
    @classmethod
    def positive_statuses(cls, value):
        if value is not None and any(item <= 0 for item in value):
            raise ValueError("Policy status IDs must be positive.")
        return value

    @field_validator(
        "required_note_phrases",
        "forbidden_note_phrases",
        "required_reply_phrases",
        "forbidden_reply_phrases",
    )
    @classmethod
    def bounded_phrases(cls, value):
        if len(value) > 50 or any(not item.strip() or len(item) > 500 for item in value):
            raise ValueError("Use at most 50 nonempty policy phrases of up to 500 characters.")
        return tuple(dict.fromkeys(item.strip() for item in value))


class PolicyBinding(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    scope: str
    controlled_policy_ids: tuple[str, ...] = ()


class PolicyVersion(BaseModel):
    policy_id: str
    version: str
    source_uri: str
    scope: str
    valid_from: AwareDatetime
    valid_to: AwareDatetime | None = None
    text: str = Field(min_length=1)
    rules: PolicyRules | None = None

    @model_validator(mode="after")
    def validate_interval(self):
        if self.valid_to is not None and self.valid_to <= self.valid_from:
            raise ValueError("A policy interval must end after it begins.")
        return self

    def active_at(self, now: datetime) -> bool:
        return self.valid_from <= now and (self.valid_to is None or now < self.valid_to)

    @property
    def key(self) -> str:
        return fingerprint(
            self.model_dump(mode="json", exclude={"rules"} if self.rules is None else set())
        )

    def evidence(self, now: datetime, *, limit: int | None = None) -> Evidence:
        return Evidence(
            source_uri=self.source_uri,
            source_kind="policy",
            entity_scope=self.scope,
            source_version=f"{self.version}:{self.key}",
            observed_at=now,
            valid_from=self.valid_from,
            valid_to=self.valid_to,
            status="observed" if self.active_at(now) else "historical",
            content=self.text if limit is None else self.text[:limit],
        )


class PolicyCatalog:
    def __init__(self, source: Path | list[PolicyVersion], scope: str):
        self.source = source
        self.scope = scope
        self._digest = None
        self._documents: list[PolicyVersion] = []
        self._retriever = None
        self._controlled_ids: set[str] = set()

    def _load(self) -> None:
        if isinstance(self.source, Path):
            raw = json.loads(self.source.read_text(encoding="utf-8"))
            digest = fingerprint(raw)
            documents = [PolicyVersion.model_validate(item) for item in raw]
        else:
            documents = self.source
            digest = fingerprint([item.model_dump(mode="json") for item in documents])
        if self._digest == digest:
            return
        seen = set()
        for item in documents:
            identity = (item.scope, item.policy_id, item.version)
            if identity in seen:
                raise ValueError("Policy versions must have unique scope, ID and version.")
            seen.add(identity)
        for index, first in enumerate(documents):
            for second in documents[index + 1 :]:
                if (first.scope, first.policy_id) != (second.scope, second.policy_id):
                    continue
                if (first.valid_to is None or second.valid_from < first.valid_to) and (
                    second.valid_to is None or first.valid_from < second.valid_to
                ):
                    raise ValueError("Published versions of the same policy overlap.")

        os.environ.setdefault("HAYSTACK_TELEMETRY_ENABLED", "false")
        from haystack import Document
        from haystack.components.retrievers.in_memory import InMemoryBM25Retriever
        from haystack.document_stores.in_memory import InMemoryDocumentStore

        store = InMemoryDocumentStore()
        store.write_documents(
            [
                Document(
                    id=item.key,
                    content=item.text,
                    meta={
                        "scope": item.scope,
                        "policy_id": item.policy_id,
                        "version": item.version,
                    },
                )
                for item in documents
            ]
        )
        self._retriever = InMemoryBM25Retriever(document_store=store, top_k=3)
        self._documents = list(documents)
        self._controlled_ids.update(
            item.policy_id
            for item in documents
            if item.scope == self.scope and item.rules is not None
        )
        self._digest = digest

    def search(self, query: str, *, top_k: int = 3, now: datetime | None = None) -> list[dict]:
        if not query.strip() or not 1 <= top_k <= 5:
            raise BusinessError("invalid_query", "Use a nonempty query and top_k from 1 to 5.")
        now = now or utc_now()
        self._load()
        current = {
            item.key: item
            for item in self._documents
            if item.scope == self.scope and item.active_at(now)
        }
        if not current:
            return []
        result = self._retriever.run(
            query=query,
            top_k=top_k,
            filters={
                "operator": "AND",
                "conditions": [
                    {"field": "meta.scope", "operator": "==", "value": self.scope},
                    {"field": "id", "operator": "in", "value": list(current)},
                ],
            },
        )
        return [
            {
                "policy_id": current[item.id].policy_id,
                "version": current[item.id].version,
                "evidence": current[item.id].evidence(now, limit=700).model_dump(mode="json"),
            }
            for item in result["documents"]
        ]

    def current(
        self, *, now: datetime | None = None, require_controlled: bool = False
    ) -> list[PolicyVersion]:
        now = now or utc_now()
        self._load()
        current = sorted(
            (item for item in self._documents if item.scope == self.scope and item.active_at(now)),
            key=lambda item: (item.policy_id, item.version),
        )
        if require_controlled:
            missing = self._controlled_ids - {
                item.policy_id for item in current if item.rules is not None
            }
            if missing:
                raise BusinessError(
                    "policy_unavailable",
                    "Publish current versions with explicit rules for the required policies: "
                    + ", ".join(sorted(missing)),
                )
        return current

    def binding(self, previous: dict | None = None) -> dict:
        bound = PolicyBinding.model_validate(previous) if previous else None
        if bound is not None and bound.scope != self.scope:
            raise BusinessError("policy_scope_changed", "Resume with the saved policy scope.")
        if bound is not None:
            self._controlled_ids.update(bound.controlled_policy_ids)
        self.current(require_controlled=True)
        return self.observed_binding(previous)

    def observed_binding(self, previous: dict | None = None) -> dict:
        bound = PolicyBinding.model_validate(previous) if previous else None
        if bound is not None and bound.scope != self.scope:
            raise BusinessError("policy_scope_changed", "Preserve the saved policy scope.")
        controlled = self._controlled_ids | (
            set(bound.controlled_policy_ids) if bound is not None else set()
        )
        return PolicyBinding(
            scope=self.scope, controlled_policy_ids=tuple(sorted(controlled))
        ).model_dump(mode="json")

    def read(self, policy_id: str, version: str = "", *, now: datetime | None = None) -> dict:
        now = now or utc_now()
        self._load()
        matches = [
            item
            for item in self._documents
            if item.scope == self.scope
            and item.policy_id == policy_id
            and (item.version == version if version else item.active_at(now))
        ]
        if len(matches) != 1:
            raise BusinessError("policy_unavailable", "Specify an available policy and version.")
        return matches[0].evidence(now).model_dump(mode="json")
