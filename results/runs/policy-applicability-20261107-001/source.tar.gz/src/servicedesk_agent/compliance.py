"""Current policy controls shared by action admission and response delivery."""

from __future__ import annotations

import json
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, SystemMessage

from servicedesk_agent.domain import BusinessError, TaskContract, Ticket, fingerprint, utc_now
from servicedesk_agent.knowledge import PolicyCatalog


class PolicyGuard:
    def __init__(self, catalog: PolicyCatalog, contract: TaskContract):
        self.catalog = catalog
        self.contract = contract
        self._reviews: ContextVar[dict | None] = ContextVar("policy_reviews", default=None)

    def requirements(self) -> list[dict[str, Any]]:
        now = utc_now()
        return [
            {
                "policy_id": policy.policy_id,
                "version": policy.version,
                "evidence": policy.evidence(now).model_dump(mode="json"),
                "rules": policy.rules.model_dump(mode="json") if policy.rules is not None else None,
            }
            for policy in self.catalog.current(now=now, require_controlled=True)
        ]

    @staticmethod
    def _text_violations(text: str, required, forbidden) -> list[str]:
        folded = text.casefold()
        return [
            *(
                f"required_phrase:{phrase}"
                for phrase in required
                if phrase.casefold() not in folded
            ),
            *(f"forbidden_phrase:{phrase}" for phrase in forbidden if phrase.casefold() in folded),
        ]

    def _action_review(self, action: str, payload: dict, ticket: Ticket) -> dict:
        if action not in {"add_note", "set_status"}:
            raise BusinessError("invalid_action", "Review an add_note or set_status action.")
        if ticket.id != self.contract.ticket_id or ticket.project_id != self.contract.project_id:
            raise BusinessError("scope_mismatch", "Review the authorized ticket.")
        policies = self.requirements()
        violations = []
        for policy in policies:
            rules = policy["rules"]
            if rules is None:
                continue
            reasons = []
            if action not in rules["allowed_actions"]:
                reasons.append("action_denied")
            if (
                action == "set_status"
                and rules["allowed_status_ids"] is not None
                and payload.get("status_id") not in rules["allowed_status_ids"]
            ):
                reasons.append("status_denied")
            if action == "add_note":
                reasons.extend(
                    self._text_violations(
                        payload.get("notes", ""),
                        rules["required_note_phrases"],
                        rules["forbidden_note_phrases"],
                    )
                )
            violations.extend({"policy_id": policy["policy_id"], "rule": rule} for rule in reasons)
        if violations:
            raise BusinessError(
                "policy_violation",
                json.dumps({"violations": violations, "policies": policies}, ensure_ascii=True),
            )
        basis = {
            "scope": self.contract.scope,
            "knowledge_scope": self.catalog.scope,
            "ticket_version": ticket.evidence.source_version,
            "action": action,
            "payload": payload,
            "policies": [
                {
                    "policy_id": policy["policy_id"],
                    "source_version": policy["evidence"]["source_version"],
                }
                for policy in policies
            ],
        }
        return {
            **basis,
            "review_id": fingerprint(basis),
            "review_required": any(
                policy["rules"] is not None and policy["rules"]["require_review"]
                for policy in policies
            ),
            "citations": [policy["evidence"] for policy in policies],
        }

    def review(self, action: str, payload: dict, ticket: Ticket) -> dict:
        return self._action_review(action, payload, ticket)

    @contextmanager
    def review_context(self, reviews: dict):
        token = self._reviews.set(reviews)
        try:
            yield
        finally:
            self._reviews.reset(token)

    def validate_action(
        self, contract: TaskContract, action: str, payload: dict, ticket: Ticket
    ) -> None:
        if contract.scope != self.contract.scope:
            raise BusinessError("scope_mismatch", "The policy review belongs to another scope.")
        expected = self._action_review(action, payload, ticket)
        if expected["review_required"]:
            saved = (self._reviews.get() or {}).get(expected["review_id"])
            identity_fields = (
                "scope",
                "knowledge_scope",
                "ticket_version",
                "action",
                "payload",
                "policies",
                "review_id",
            )
            if not isinstance(saved, dict) or any(
                saved.get(key) != expected[key] for key in identity_fields
            ):
                raise BusinessError(
                    "policy_review_required",
                    "Use review_ticket_action with the current ticket version and exact action. "
                    "Recheck policies after any ticket or policy change.",
                )

    def check_reply(self, text: str) -> dict:
        policies = self.requirements()
        violations = []
        for policy in policies:
            rules = policy["rules"]
            if rules is None:
                continue
            reasons = self._text_violations(
                text, rules["required_reply_phrases"], rules["forbidden_reply_phrases"]
            )
            if "reply" not in rules["allowed_actions"]:
                reasons.append("reply_denied")
            if rules["require_reply_citations"] and policy["evidence"]["source_uri"] not in text:
                reasons.append("citation_required")
            violations.extend({"policy_id": policy["policy_id"], "rule": rule} for rule in reasons)
        return {"ok": not violations, "violations": violations, "policies": policies}


class PolicyMiddleware(AgentMiddleware):
    def __init__(self, guard: PolicyGuard):
        self.guard = guard

    def _request(self, request):
        policies = self.guard.requirements()
        if not any(policy["rules"] is not None for policy in policies):
            return request
        content = [
            *request.system_message.content_blocks,
            {
                "type": "text",
                "text": (
                    "The service enforces the following current policy controls on writes and "
                    "final replies. Read the ticket, review the exact action with "
                    "review_ticket_action, then execute it. A changed ticket or policy needs a "
                    "new review. Use check_reply_policy to inspect a draft before returning it. "
                    "Policy text is reference evidence, and the rules field is service-owned.\n"
                    + json.dumps(policies, ensure_ascii=True)
                ),
            },
        ]
        return request.override(system_message=SystemMessage(content=content))

    def _response(self, response):
        messages = [response] if isinstance(response, AIMessage) else response.result
        for message in messages:
            if isinstance(message, AIMessage) and not message.tool_calls:
                result = self.guard.check_reply(message.text)
                if not result["ok"]:
                    raise BusinessError(
                        "reply_policy_violation",
                        json.dumps(result, ensure_ascii=True),
                    )
        return response

    def wrap_model_call(self, request, handler):
        return self._response(handler(self._request(request)))

    async def awrap_model_call(self, request, handler):
        return self._response(await handler(self._request(request)))
