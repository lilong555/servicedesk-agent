# ServiceDesk Agent

基于 DeepAgents 的 IT 服务台工单处理与跨会话交接 Agent。

核心依赖为 DeepAgents 0.7.32、LangGraph 1.2.20 和 SQLite Checkpointer。
业务后端使用 Redmine，任务验收使用固定版本的 CRM-Agent-Bench。
